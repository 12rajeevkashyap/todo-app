import React, { Component } from 'react'
import jwt_decode from 'jwt-decode'
import axios from 'axios'
import { json } from 'body-parser'

class Profile extends Component {
  constructor() {
    super()
    this.state = {
      first_name: '',
      last_name: '',
      email: '',
      errors: {},
      items:[],
      globalitem:{}
    }
  }

  componentDidMount() {
   

    axios.get('https://api.covid19api.com/summary')
    .then(res=>{  
      this.setState({items:res.data.Countries})
      this.setState({globalitem:res.data.Global})
     
       console.log(JSON.stringify(res))
      }).
      catch(ex=>{
        console.log(ex)
      })

      const token = localStorage.usertoken
      const decoded = jwt_decode(token)
      this.setState({
        first_name: decoded.first_name,
        last_name: decoded.last_name,
        email: decoded.email
      })

  }

  render() {
   
   
    
    return (
      <div className="container">
       
       <div>
        
          <table className="table col-md-6 mx-auto">
            <tbody>
              <tr style={{position:"absolute",left:"700px"}}>
                <td><h3>Name</h3></td>
                <td ><h3>{this.state.first_name} {this.state.last_name}</h3></td>
              </tr>
              
            </tbody>
          </table>
        </div><br></br><br/><br/><br/>
  <h2>Global cases</h2>
            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>NewConfirmed</th>
        <th>TotalConfirmed</th>
        <th style={{color:"red"}}>NewDeaths</th>
        <th>TotalDeaths</th>
        <th style={{color:"green"}}>NewRecovered</th>
        <th>TotalRecovered</th>
      </tr>
    </thead>
    <tbody>
    <td>{JSON.stringify(this.state.globalitem.NewConfirmed)}</td>
    <td>{JSON.stringify(this.state.globalitem.TotalConfirmed)}</td>
    <td style={{color:"red"}}>{JSON.stringify(this.state.globalitem.NewDeaths)}</td>
    <td>{JSON.stringify(this.state.globalitem.TotalDeaths)}</td>
    <td style={{color:"green"}}>{JSON.stringify(this.state.globalitem.NewRecovered)}</td>
    <td>{JSON.stringify(this.state.globalitem.TotalRecovered)}</td>
    {/* {this.state.globalitem.map((person1, index) => (
       
       <tr>
       <td>{person1.NewConfirmed}</td>
       <td>{person1.NewConfirmed}</td>
       <td>{person1.NewConfirmed}</td>
      
     </tr>
       
   ))} */}
     
    </tbody>
  </table>



  <h2>Country cases</h2>
      
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Country</th>
        <th>CountryCode</th>
        <th>NewConfirmed</th>
        <th>TotalConfirmed</th>
        <th style={{color:"red"}}>NewDeaths</th>
        <th style={{color:"red"}}>TotalDeaths</th>
        <th style={{color:"green"}}>NewRecovered</th>
        <th style={{color:"green"}}>TotalRecovered</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
    {this.state.items.map((person, index) => (
       
        <tr>
        <td>{person.Country}</td>
        <td>{person.CountryCode}</td>
        <td>{person.NewConfirmed}</td>
        <td>{person.TotalConfirmed}</td>
        <td style={{color:"red"}}>{person.NewDeaths}</td>
        <td style={{color:"red"}}>{person.TotalDeaths}</td>
        <td style={{color:"green"}}>{person.NewRecovered}</td>
        <td style={{color:"green"}}>{person.TotalRecovered}</td>
        <td>{person.Date}</td>
      </tr>
        
    ))}
     
      
    </tbody>
  </table>
  
        
       
       
      </div>
    )
  }
}

export default Profile
