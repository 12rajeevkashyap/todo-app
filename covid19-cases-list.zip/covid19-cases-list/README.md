# MERN Login and Registration (MongoDB, Express, ReactJS, NodeJS)

![MERN Todo](../screenshots/react-login1.PNG)
#
![MERN Todo](../screenshots/react-login2.PNG)


## Setup

Manually clone the repo and then run `npm install`.